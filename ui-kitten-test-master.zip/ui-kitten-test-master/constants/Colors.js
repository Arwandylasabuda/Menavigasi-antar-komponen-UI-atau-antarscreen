export default {
    primaryColor: '#6AB187',
    primaryVariant: '#20948B',
    secondaryColor: '#DE7A22',
    secondaryVariant: '#F4CC70',
}
