module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      [
        'module-resolver',
        {
          alias: {
            '@src': './kitten',
            '@kitten': 'react-native-ui-kitten',
          },
        },
      ],
    ],
  };
};
